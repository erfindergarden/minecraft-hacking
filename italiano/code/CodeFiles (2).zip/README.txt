Adventures in Minecraft
Code files

For the book: "Adventures in Minecraft"
written by David Whale and Martin O'Hanlon, Wiley, 2014
http://eu.wiley.com/WileyCDA/WileyTitle/productCd-111894691X.html

-------------------------------

Description
------------------------------- 
This zip file contains all the code files from the Adventures in Minecraft series.

The files are split into folders, 1 for each adventure.

IMPORTANT NOTE - You should copy the individual code file to the MyAdventures folder and run it from there as the programs will need the api's and libraries which are held in the MyAdventures/mcpi folder.

