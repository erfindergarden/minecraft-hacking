# Adventure 8: RandomNumber.py

# From the book: "Adventures in Minecraft"
# written by David Whale and Martin O'Hanlon, Wiley, 2014
# http://eu.wiley.com/WileyCDA/WileyTitle/productCd-111894691X.html

import random
randomNo = random.randint(1,10)
print randomNo
