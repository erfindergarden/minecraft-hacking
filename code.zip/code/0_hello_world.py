from time import sleep

print "hello world"


#while True
#   print "hello world"
#   sleep(1)